# settings/production.py
from .base import *
DEBUG = False
ALLOWED_HOSTS = ['neuralnavigate.com', 'www.neuralnavigate.com', 'neuralnavigate-prod-env.eba-jpr6yccf.us-west-1.elasticbeanstalk.com']
