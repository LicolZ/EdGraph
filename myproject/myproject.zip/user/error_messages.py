EMAIL_EXISTS = "A user is already registered with this e-mail address"
EMAIL_INVALID = "Please enter a valid email"
MISSING_FIELD_INPUT = "Required"
INVALID_CREDENTIALS = "Invalid login credentials"
